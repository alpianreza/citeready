# CiteReady Pro v1.0.0 — Quick Start

Thank you for picking up **CiteReady Pro**!

## Requirements
- **Node.js 18+** (zero `npm install` needed — zero external dependencies)

## 1. Run Your First Full Audit & Generate All 6 Fix Files
```bash
node bin/citeready.mjs https://yourdomain.com --fix --out ./citeready-output
```

## 2. White-Label Client Report (HTML + Print-to-PDF)
```bash
node bin/citeready.mjs https://client.com --fix --brand "Your Studio" --out ./client-audit
```
Open `citeready-report.html` in your browser and click **Save / Print as PDF**.

## 3. Audit a Local Static Build Before Deploying + CI Score Gate
```bash
node bin/citeready.mjs --dir ./dist --url https://yourdomain.com --fix --min-score 85
```
See `.github/workflows/citeready-gate.yml` for a ready-to-use GitHub Actions workflow.
