# CiteReady Free Lite v1.0.0

Zero-dependency AI Search (GEO), `llms.txt`, AI crawler `robots.txt`, JSON-LD & Technical SEO auditor.

## Requirements
- **Node.js 18+** (zero `npm install` required)

## Usage
```bash
# Audit a live homepage (36 real checks)
node bin/citeready-lite.mjs https://yourdomain.com

# Output JSON for scripts
node bin/citeready-lite.mjs https://yourdomain.com --json

# Enforce a score threshold in terminal
node bin/citeready-lite.mjs https://yourdomain.com --min-score 80
```

## Upgrade to CiteReady Pro ($19 One-Time)
CiteReady Pro unlocks:
- Multi-page internal crawling (`--crawl 10+`)
- Auto-generation of 6 drop-in fix files (`--fix`: `llms.txt`, `llms-full.txt`, `robots.txt`, `jsonld-snippets.html`, `head-meta-patch.html`, `nextjs-metadata.ts`)
- White-label standalone HTML / Print-PDF audit report (`--brand`)
- GitHub Actions CI/CD score gate workflow

- Get CiteReady Pro CLI ($19 one-time): https://eiran.gumroad.com/l/shubyl
- Order Done-For-You 24h Fix Pack ($29): https://eiran.gumroad.com/l/eiosatl
- Website & Interactive Browser Toolkit: https://citeready.eiran.tech
