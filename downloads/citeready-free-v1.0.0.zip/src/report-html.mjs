/**
 * Standalone, zero-dependency, print-to-PDF ready HTML report renderer.
 */

import { escapeHtml } from './html-parser.mjs';

function scoreColor(score) {
  if (score >= 85) return '#0f766e';
  if (score >= 65) return '#b45309';
  return '#b91c1c';
}

function badgeStyle(severity) {
  if (severity === 'pass') return 'background:#ecfdf5;color:#065f46;border:1px solid #a7f3d0;';
  if (severity === 'warning') return 'background:#fffbeb;color:#92400e;border:1px solid #fde68a;';
  return 'background:#fef2f2;color:#991b1b;border:1px solid #fecaca;';
}

function severityLabel(severity) {
  if (severity === 'pass') return 'PASS';
  if (severity === 'warning') return 'WARNING';
  return 'CRITICAL';
}

export function renderHtmlReport(auditResult, fixes = {}, options = {}) {
  const brand = options.brand ? String(options.brand).trim() : 'CiteReady';
  const color = scoreColor(auditResult.score);
  const radius = 54;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (Math.max(0, Math.min(100, auditResult.score)) / 100) * circumference;

  const demoBanner = options.demoNotice
    ? `<div class="demo-banner">${escapeHtml(options.demoNotice)}</div>`
    : '';

  const pillarCards = auditResult.pillars
    .map((p) => {
      const pColor = scoreColor(p.pct);
      return `
      <div class="pillar-card">
        <div class="pillar-top">
          <span class="pillar-name">${escapeHtml(p.name)}</span>
          <span class="pillar-pts">${p.earned} / ${p.maxPoints} pts</span>
        </div>
        <div class="bar-track"><div class="bar-fill" style="width:${p.pct}%;background:${pColor};"></div></div>
        <div class="pillar-sub">${p.passed} of ${p.total} checks passed (${p.pct}%)</div>
      </div>`;
    })
    .join('');

  const crawlerRows = auditResult.crawlers.bots
    .map((bot) => {
      const allowed = bot.allowed;
      const badge = allowed
        ? 'background:#ecfdf5;color:#065f46;border:1px solid #a7f3d0;'
        : 'background:#fef2f2;color:#991b1b;border:1px solid #fecaca;';
      const statusText = allowed
        ? bot.explicit
          ? 'Allowed (Explicit)'
          : 'Allowed (Default)'
        : 'BLOCKED';
      return `
      <tr>
        <td><code>${escapeHtml(bot.name)}</code></td>
        <td>${escapeHtml(bot.owner)}</td>
        <td>${escapeHtml(bot.role === 'search' ? 'AI Search / Citations' : 'Model Training')}</td>
        <td>${escapeHtml(bot.label)}</td>
        <td><span class="pill" style="${badge}">${escapeHtml(statusText)}</span></td>
      </tr>`;
    })
    .join('');

  const sortedChecks = [...auditResult.checks].sort((a, b) => {
    const rank = { critical: 0, warning: 1, pass: 2 };
    return rank[a.severity] - rank[b.severity];
  });

  const checkRows = sortedChecks
    .map((c) => {
      return `
      <div class="check-item">
        <div class="check-head">
          <div>
            <span class="pill" style="${badgeStyle(c.severity)}">${severityLabel(c.severity)}</span>
            <strong>${escapeHtml(c.title)}</strong>
          </div>
          <span class="pts-tag">${c.earned}/${c.maxPoints} pts</span>
        </div>
        <p class="check-detail">${escapeHtml(c.detail)}</p>
        ${c.severity !== 'pass' ? `<p class="check-fix"><strong>Fix:</strong> ${escapeHtml(c.fixHint)}</p>` : ''}
      </div>`;
    })
    .join('');

  const fixEntries = Object.entries(fixes || {});
  const fixTabs = fixEntries
    .map(([name], idx) => {
      return `<button type="button" class="tab-btn${idx === 0 ? ' active' : ''}" data-tab="fix-${idx}">${escapeHtml(name)}</button>`;
    })
    .join('');

  const fixPanels = fixEntries
    .map(([name, content], idx) => {
      return `
      <div class="tab-panel${idx === 0 ? ' active' : ''}" id="fix-${idx}">
        <div class="panel-bar">
          <code>${escapeHtml(name)}</code>
          <button type="button" class="copy-btn" data-copy-target="code-${idx}">Copy File</button>
        </div>
        <pre id="code-${idx}"><code>${escapeHtml(content)}</code></pre>
      </div>`;
    })
    .join('');

  const pageRows = (auditResult.pages || [])
    .map(
      (p) => `
      <tr>
        <td><code>${escapeHtml(p.path)}</code></td>
        <td>${p.status}</td>
        <td>${escapeHtml(p.title || '(no title)')}</td>
        <td>${p.wordCount}</td>
      </tr>`
    )
    .join('');

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${escapeHtml(brand)} Audit Report — ${escapeHtml(auditResult.origin)}</title>
  <style>
    :root {
      --bg: #f8fafc;
      --surface: #ffffff;
      --ink: #0f172a;
      --muted: #475569;
      --border: #e2e8f0;
      --accent: #0f766e;
    }
    * { box-sizing: border-box; }
    body {
      margin: 0;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Inter, sans-serif;
      background: var(--bg);
      color: var(--ink);
      line-height: 1.5;
    }
    .wrap { max-width: 1080px; margin: 0 auto; padding: 32px 20px 64px; }
    .demo-banner {
      background: #0f172a;
      color: #f8fafc;
      padding: 10px 16px;
      border-radius: 8px;
      margin-bottom: 18px;
      font-size: 13px;
    }
    .header {
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: 14px;
      padding: 28px;
      display: grid;
      grid-template-columns: 1fr auto;
      gap: 24px;
      align-items: center;
    }
    .brand-tag {
      display: inline-block;
      font-size: 12px;
      font-weight: 700;
      letter-spacing: 0.06em;
      text-transform: uppercase;
      color: var(--accent);
      margin-bottom: 8px;
    }
    h1 { margin: 0 0 6px; font-size: 26px; line-height: 1.2; }
    .meta-line { color: var(--muted); font-size: 14px; margin: 0; }
    .summary-badges { display: flex; flex-wrap: wrap; gap: 10px; margin-top: 16px; }
    .stat-chip {
      padding: 6px 12px;
      border-radius: 999px;
      font-size: 13px;
      font-weight: 600;
      border: 1px solid var(--border);
      background: #f8fafc;
    }
    .score-ring-box { text-align: center; }
    .score-ring-wrap { position: relative; width: 136px; height: 136px; }
    .score-center {
      position: absolute;
      inset: 0;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
    }
    .score-num { font-size: 34px; font-weight: 800; line-height: 1; }
    .score-sub { font-size: 12px; color: var(--muted); margin-top: 4px; font-weight: 600; }
    .section {
      margin-top: 24px;
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: 14px;
      padding: 24px;
    }
    .section h2 { margin: 0 0 16px; font-size: 18px; }
    .pillar-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
      gap: 14px;
    }
    .pillar-card {
      border: 1px solid var(--border);
      border-radius: 10px;
      padding: 14px;
      background: #fcfcfd;
    }
    .pillar-top { display: flex; justify-content: space-between; font-weight: 700; font-size: 14px; margin-bottom: 8px; }
    .pillar-pts { color: var(--muted); font-variant-numeric: tabular-nums; }
    .bar-track { height: 8px; background: #e2e8f0; border-radius: 999px; overflow: hidden; }
    .bar-fill { height: 100%; border-radius: 999px; }
    .pillar-sub { font-size: 12px; color: var(--muted); margin-top: 8px; }
    table { width: 100%; border-collapse: collapse; font-size: 14px; }
    th, td { text-align: left; padding: 10px 12px; border-bottom: 1px solid var(--border); }
    th { font-size: 12px; text-transform: uppercase; letter-spacing: 0.04em; color: var(--muted); }
    .pill {
      display: inline-block;
      padding: 2px 8px;
      border-radius: 999px;
      font-size: 11px;
      font-weight: 700;
      margin-right: 6px;
      vertical-align: middle;
    }
    .check-item { padding: 14px 0; border-bottom: 1px solid var(--border); }
    .check-item:last-child { border-bottom: none; }
    .check-head { display: flex; justify-content: space-between; align-items: center; gap: 12px; }
    .pts-tag { font-size: 12px; font-weight: 700; color: var(--muted); white-space: nowrap; }
    .check-detail { margin: 6px 0 0; font-size: 14px; color: var(--muted); }
    .check-fix { margin: 6px 0 0; font-size: 13px; color: #0f172a; background: #f1f5f9; padding: 8px 10px; border-radius: 6px; }
    .tab-bar { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 12px; }
    .tab-btn {
      border: 1px solid var(--border);
      background: #f8fafc;
      color: var(--ink);
      padding: 7px 12px;
      border-radius: 8px;
      font-size: 13px;
      font-weight: 600;
      cursor: pointer;
    }
    .tab-btn.active { background: #0f172a; color: #fff; border-color: #0f172a; }
    .tab-panel { display: none; }
    .tab-panel.active { display: block; }
    .panel-bar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: #0f172a;
      color: #e2e8f0;
      padding: 8px 14px;
      border-radius: 10px 10px 0 0;
      font-size: 13px;
    }
    .copy-btn {
      background: #1e293b;
      color: #f8fafc;
      border: 1px solid #334155;
      border-radius: 6px;
      padding: 4px 10px;
      font-size: 12px;
      cursor: pointer;
    }
    pre {
      margin: 0;
      background: #020617;
      color: #e2e8f0;
      padding: 16px;
      border-radius: 0 0 10px 10px;
      overflow-x: auto;
      font-size: 12.5px;
      line-height: 1.5;
      max-height: 440px;
    }
    .actions-top { display: flex; gap: 10px; margin-top: 12px; }
    .print-btn {
      background: #0f766e;
      color: #fff;
      border: none;
      padding: 8px 14px;
      border-radius: 8px;
      font-weight: 600;
      font-size: 13px;
      cursor: pointer;
    }
    footer { margin-top: 28px; text-align: center; font-size: 13px; color: var(--muted); }
    @media print {
      body { background: #fff; }
      .print-btn, .copy-btn, .tab-bar { display: none !important; }
      .tab-panel { display: block !important; margin-bottom: 16px; }
      .section, .header { break-inside: avoid; }
    }
    @media (max-width: 700px) {
      .header { grid-template-columns: 1fr; }
    }
  </style>
</head>
<body>
  <div class="wrap">
    ${demoBanner}
    <header class="header">
      <div>
        <span class="brand-tag">${escapeHtml(brand)} — AI Search & Launch Readiness Report</span>
        <h1>${escapeHtml(auditResult.origin)}</h1>
        <p class="meta-line">
          Target: <code>${escapeHtml(auditResult.url)}</code> &middot;
          Mode: ${escapeHtml(auditResult.mode)} &middot;
          Pages Crawled: ${auditResult.meta.pagesCrawled} &middot;
          Audited: ${escapeHtml(auditResult.auditedAt)}
        </p>
        <div class="summary-badges">
          <span class="stat-chip" style="color:#991b1b;">${auditResult.summary.critical} Critical</span>
          <span class="stat-chip" style="color:#92400e;">${auditResult.summary.warning} Warnings</span>
          <span class="stat-chip" style="color:#065f46;">${auditResult.summary.pass} Passed</span>
        </div>
        <div class="actions-top">
          <button type="button" class="print-btn" onclick="window.print()">Save / Print as PDF</button>
        </div>
      </div>
      <div class="score-ring-box">
        <div class="score-ring-wrap">
          <svg width="136" height="136" viewBox="0 0 136 136" aria-hidden="true">
            <circle cx="68" cy="68" r="${radius}" fill="none" stroke="#e2e8f0" stroke-width="12"/>
            <circle cx="68" cy="68" r="${radius}" fill="none" stroke="${color}" stroke-width="12"
              stroke-linecap="round"
              stroke-dasharray="${circumference.toFixed(2)}"
              stroke-dashoffset="${offset.toFixed(2)}"
              transform="rotate(-90 68 68)"/>
          </svg>
          <div class="score-center">
            <span class="score-num" style="color:${color};">${auditResult.score}</span>
            <span class="score-sub">Grade ${escapeHtml(auditResult.grade)} / 100</span>
          </div>
        </div>
      </div>
    </header>

    <section class="section">
      <h2>Pillar Breakdown</h2>
      <div class="pillar-grid">${pillarCards}</div>
    </section>

    <section class="section">
      <h2>AI Crawler & Citation Access Matrix (robots.txt)</h2>
      <table>
        <thead>
          <tr><th>Bot</th><th>Owner</th><th>Purpose</th><th>Engine</th><th>Status</th></tr>
        </thead>
        <tbody>${crawlerRows}</tbody>
      </table>
    </section>

    <section class="section">
      <h2>36-Check Audit Findings</h2>
      ${checkRows}
    </section>

    ${
      fixEntries.length > 0
        ? `<section class="section">
      <h2>Generated Drop-In Fix Files</h2>
      <div class="tab-bar">${fixTabs}</div>
      ${fixPanels}
    </section>`
        : ''
    }

    <section class="section">
      <h2>Crawled Pages (${(auditResult.pages || []).length})</h2>
      <table>
        <thead><tr><th>Path</th><th>Status</th><th>Title</th><th>Words</th></tr></thead>
        <tbody>${pageRows}</tbody>
      </table>
    </section>

    <footer>
      Generated by ${escapeHtml(brand)} &middot; Zero-dependency AI Search (GEO) & Launch Audit Engine
    </footer>
  </div>

  <script>
    document.querySelectorAll('.tab-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.tab-btn').forEach((b) => b.classList.remove('active'));
        document.querySelectorAll('.tab-panel').forEach((p) => p.classList.remove('active'));
        btn.classList.add('active');
        const panel = document.getElementById(btn.getAttribute('data-tab'));
        if (panel) panel.classList.add('active');
      });
    });
    document.querySelectorAll('.copy-btn').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const el = document.getElementById(btn.getAttribute('data-copy-target'));
        if (!el) return;
        try {
          await navigator.clipboard.writeText(el.innerText);
          const orig = btn.textContent;
          btn.textContent = 'Copied!';
          setTimeout(() => { btn.textContent = orig; }, 1500);
        } catch {
          btn.textContent = 'Copy manually';
        }
      });
    });
  </script>
</body>
</html>
`;
}
